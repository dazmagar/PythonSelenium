var init = function () {
    chrome.runtime.onInstalled.addListener(function (object) {
        chrome.notifications.create("T_" + Date.now(), {
            type: 'basic',
            iconUrl: 'images/pysel_icon.png',
            title: 'PySel Extension',
            message: 'PySel Extension',
            priority: 2
        });
    });
    chrome.browserAction.onClicked.addListener(function (tab) { });
    chrome.webNavigation.onCompleted.addListener(function (details) { });
    chrome.tabs.onActivated.addListener(function (activeInfo) { });
};
init();
